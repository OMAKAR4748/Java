package com.xworkz.external;

import com.xworkz.casting.PublicServant;
import com.xworkz.casting.TicketCollector;

public class Railways {
    public void validateTicket(PublicServant servant)
    {
        System.out.println("Validate Ticket");
        servant.protectIPC();

        if (servant instanceof TicketCollector)
        {
            TicketCollector ticketCollector=(TicketCollector) servant;
            ticketCollector.checkTicket();
            ticketCollector.protectIPC();
        }
    }

}
