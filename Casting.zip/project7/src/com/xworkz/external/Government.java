package com.xworkz.external;

import com.xworkz.casting.PoliceOfficer;
import com.xworkz.casting.PublicServant;

public class Government {
    public void run(PublicServant servant)
    {
        System.out.println("run");
        servant.protectIPC();

        if (servant instanceof PoliceOfficer)
        {
            PoliceOfficer policeOfficer=(PoliceOfficer) servant;
            policeOfficer.controlCrime();
            policeOfficer.protectIPC();
        }
    }
}
