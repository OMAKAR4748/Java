package com.xworkz.Runner;

import com.xworkz.casting.*;
import com.xworkz.external.Government;
import com.xworkz.external.PoliceStation;
import com.xworkz.external.Railways;

import java.util.Arrays;

public class PublicServantRunner {
    public static void main(String[] args) {

        PublicServant servant=new PoliceOfficer();
        PublicServant servant1=new TicketCollector();

        System.out.println("=============================================================");

        PoliceOfficer policeOfficer=new Inspector();
        PoliceOfficer policeOfficer1=new TrafficPolice();

        System.out.println("=============================================================");

        Government government=new Government();
        government.run(servant);

        System.out.println("=============================================================");

        PoliceStation policeStation=new PoliceStation();
        policeStation.justice(policeOfficer);

        System.out.println("=============================================================");

        Railways railways=new Railways();
        railways.validateTicket(servant);

    }
}
